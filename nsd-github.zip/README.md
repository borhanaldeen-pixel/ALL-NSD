# N.S.D | نظام إدارة الإنتاج وسحب البودرة والعطور

تطبيق ويب (PWA) يعمل من ملف `index.html` واحد، ويُثبَّت على الموبايل ويعمل بدون إنترنت بعد أول فتح.

## ملفات المستودع (كلها في الجذر بدون مجلدات)

| الملف | الوظيفة |
|---|---|
| `index.html` | التطبيق نفسه (ملفك الأصلي بعد التعديلين أدناه) |
| `manifest.json` | بيانات التثبيت كتطبيق |
| `sw.js` | العمل بدون إنترنت |
| `icon-192.png` / `icon-512.png` / `icon-maskable-512.png` | أيقونات التطبيق |
| `apple-touch-icon.png` | أيقونة آيفون |

## التعديلان المطلوبان في index.html

**1) في الـ head — استبدل:**
```html
<meta name="theme-color" content="#0F172A">
```
**بـ:**
```html
<meta name="theme-color" content="#0F172A">
<link rel="manifest" href="manifest.json">
<link rel="icon" type="image/png" href="icon-192.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="N.S.D">
```

**2) في آخر السكربت — استبدل:**
```js
      initEmployeeLookup();
```
**بـ:**
```js
      initEmployeeLookup();
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('sw.js').catch(function (e) { console.warn('SW failed', e); });
      }
```

## النشر على GitHub Pages
1. أنشئ مستودعاً جديداً وارفع الملفات كلها في الجذر.
2. Settings ← Pages ← Source: `Deploy from a branch` ← Branch: `main` / `(root)` ← Save.
3. الرابط: `https://USERNAME.github.io/REPO/`
4. من الموبايل: افتح الرابط ← "إضافة إلى الشاشة الرئيسية".

## تحديث التطبيق لاحقاً
عدّل `index.html` وارفعه. وإذا غيّرت `sw.js` أو أيقونات، غيّر `VERSION` في أول `sw.js` (مثلاً `nsd-v2`).
